const express = require("express");
const jwt = require("jsonwebtoken");
const {APP_SECRET_KEY  }= require("./config");
const app = express();
const bcrypt = require("bcrypt");

require("./db")

const AuthMiddleware = require("./middleware/auth")
const AdminMiddleware = require("./middleware/admin")

const UserRouter = require("./routes/user");
const ShoppinglistRouter = require("./routes/shoppinglist");
const { ShoppingModel } = require("./schema/shopping");
const { UserModel } = require("./schema/user");
app.use(express.json());
app.use("/user",  UserRouter)
app.use("/Shopping" ,AuthMiddleware, ShoppinglistRouter)
app.get("/find-products" ,AuthMiddleware, (req, res) => {
    const doc = ShoppingModel.findOne({"Price": {$eq:"$276.68"} }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Result : ", docs);
        }
    });
})

app.get("/find-products" ,AuthMiddleware, AdminMiddleware, (req, res) => {
    
    const doc = ShoppingModel.findOne({"Price": {$eq:"$276.68"} }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Result : ", docs);
        }
    });
    
    
})

app.post("/add-products",AuthMiddleware, AdminMiddleware,  (req,res)=>{
    try{
        const {body} = req;
        const {id,Product,Date,Price } = body
        if(id && Product && Price  && id !== "" && Product !== "", Price !== ""){            
            const newItem = new ShoppingModel({id , Product ,Date , Price})
            const doc =  newItem.save();
        res.json({message: "new Item added", id: doc._id})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error"})
    }
  
})


app.get("/userList" ,AuthMiddleware, AdminMiddleware, (req, res) => {
    
    const doc = UserModel.find({}, { email: 1, _id: 0 }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Result : ", docs);
        }
    });
    
    
})

app.post("/registerAdmin", AuthMiddleware, AdminMiddleware, async (req,res)=>{
    try{
        const {body} = req;
        const {email,password} = body
        if(email && password && email !== "" && password !== ""){
            const encryptedPassword  = await bcrypt.hash(password, 10)
            const newUser = new UserModel({email, password : encryptedPassword })
            const doc =  await   newUser.save();
        res.json({message: "new user added via admin", id: doc._id})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error - admin"})
    }
  
})

app.listen(6701)