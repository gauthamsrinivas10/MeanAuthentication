const jwt = require("jsonwebtoken");
const {APP_SECRET_KEY  }= require("../config");
const { UserModel } = require("../schema/user");
const { ShoppingModel } = require("../schema/shopping");

async function AuthMiddleware(req, res, next)
{
    try
    {const { headers }  = req;
    const { authorization } = headers;

    const payload = jwt.verify(authorization, APP_SECRET_KEY);
    console.log(payload);
    const doc = await UserModel.findById(payload.id , "-password")
    req.user = doc;
    next()
}
    catch(error)
    {
        res.status(401).json({message : "Invalid user." })
    }
        
       
}
module.exports = AuthMiddleware;
    