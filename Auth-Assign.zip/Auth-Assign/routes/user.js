const {Router} = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const app = Router();
const { UserModel } =  require("../schema/user")

const {APP_SECRET_KEY  }= require("../config")
app.post("/login", async ( req, res)=>{

    try{
const {body} = req;
const { email, password} = body;

const doc = await UserModel.findOne({email });
if(doc)
{
    console.log(doc);
    const result = await bcrypt.compare(password, doc.password);
    if(result)
    {
        const token = jwt.sign({id: doc._id}, APP_SECRET_KEY , {expiresIn : 3600})
        res.json({message : "user logged in ", token})
       
    }
    else
    {
        res.status(401).json({message: "Invalid email or/and password"})
    }
}
    

else
{
    res.status(401).json({message: "Invalid email and/or password"})
}

    }
    catch (error){
        res.status(500).json({message: "Internal server error"})
    }
})

app.post("/register", async (req,res)=>{
    try{
        const {body} = req;
        const {email,password} = body
        if(email && password && email !== "" && password !== ""){
            const encryptedPassword  = await bcrypt.hash(password, 10)
            const newUser = new UserModel({email, password : encryptedPassword})
            const doc = await newUser.save();
        res.json({message: "new user added", id: doc._id})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error"})
    }
  
})
module.exports  = app;