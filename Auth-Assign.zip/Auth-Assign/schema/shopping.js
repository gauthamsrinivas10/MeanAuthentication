const { Schema, model} = require("mongoose");

const ShoppingSchema = new Schema({
    id : {type: String, required: true},
    Product : {type:String , required:true},
    Date: {type:Date, default: new Date()},
    Price : {type:String , required : true }
})

const ShoppingModel = model("shopping",ShoppingSchema , "ShoppingList" );
module.exports = {ShoppingSchema, ShoppingModel}